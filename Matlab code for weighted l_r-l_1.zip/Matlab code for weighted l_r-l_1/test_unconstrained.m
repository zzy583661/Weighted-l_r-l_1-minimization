function error = test_unconstrained(k,p,alpha,noise_type,nsim) 

% Calculate the reconstruction error for different p (r in the paper) and sparsity k (s in the paper) 
%  with different noise_type (0,1) and nsim replications
% tic;
randn('seed',1);
%% noise_type
if noise_type==0
sigma=0;
lambda=1e-6;

elseif noise_type==1
sigma=0.01;
lambda=1e-4;
end
%%
rase=zeros(nsim,1);
%%Gaussian random matrix
N=256;
m=64;
rng(0,'twister');
A = randn(m,N)/sqrt(m); 


for j=1:nsim
 
%% simulate the signal (exactly sparse)
x0 = zeros(N,1); 
x0(randsample(N,k)) = randn(k,1);
  
%% main recovery code
y = A*x0+sigma*randn(m,1);   
xhat=lp_unconstrained(A,y,p,alpha,lambda);
if noise_type==0
    rase(j)=norm(x0-xhat)/norm(x0);
    if rase(j)<1e-3
        rase(j)=1;
    else
        rase(j)=0;
    end
elseif noise_type== 1
rase(j)=20*log10(norm(x0)/norm(x0-xhat));
end


end 
%% error calculation 
error=mean(rase);
%toc


