All figures in the paper "A new nonconvex sparse recovery method for compressive sensing" can be reproduced from the codes here. Precisely,

Figure 1- contour_plot
Figure 2- plot_successrecovery (noise_type=0)
Figure 3- plot_successrecoverydifferentr (noise_type=0)
Figure 4- plot_successrecovery (noise_type=1)
Figure 5- plot_successrecoverydifferentr (noise_type=1)
Figure 6- plot_algorithmcomparison

Please see the comments therein for details. 