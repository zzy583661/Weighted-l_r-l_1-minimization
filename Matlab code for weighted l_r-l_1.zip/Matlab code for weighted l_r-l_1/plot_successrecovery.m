%% Codes for Figure 2 (noiseless case) and Figure 4 (noisy case)
%% Successful recovery rate for different alpha with r=0.3 and r=0.7

s=[10 12 14 16 18 20 22 24 26 28 30 32 34 36]';
noise_type=0;
nsim=100;
alpha=[0 0.2 0.5 0.8 1]';
p1=0.3;
error1=zeros(length(s),length(alpha));
for i=1:length(alpha)
    for j=1:length(s)
    error1(j,i)=test_unconstrained(s(j),p1,alpha(i),noise_type,nsim);
    end
end
p2=0.7;
error2=zeros(length(s),length(alpha));
for i=1:length(alpha)
    for j=1:length(s)
    error2(j,i)=test_unconstrained(s(j),p2,alpha(i),noise_type,nsim);
    end
end

%% noisy_type=0 noisless case
subplot(1,2,1)
plot(s,error1(:,1),'-o',s,error1(:,2),'-+',s,error1(:,3),'-*',s,error1(:,4),'-s',s,error1(:,5),'-d');
set(gca,'FontSize',22);
legend('\alpha=0','\alpha=0.2','\alpha=0.5','\alpha=0.8','\alpha=1');
title('$r=0.3$','Interpreter','latex')
xlabel('Sparsity Level s')
ylabel('Successful Rate')

subplot(1,2,2)
plot(s,error2(:,1),'-o',s,error2(:,2),'-+',s,error2(:,3),'-*',s,error2(:,4),'-s',s,error2(:,5),'-d');
set(gca,'FontSize',22);
legend('\alpha=0','\alpha=0.2','\alpha=0.5','\alpha=0.8','\alpha=1');
title('$r=0.7$','Interpreter','latex')
xlabel('Sparsity Level s')
ylabel('Successful Rate')

%% noisy_type=1 noisy case
% subplot(1,2,1)
% plot(s,error1(:,1),'-o',s,error1(:,2),'-+',s,error1(:,3),'-*',s,error1(:,4),'-s',s,error1(:,5),'-d');
% set(gca,'FontSize',22);
% legend('\alpha=0','\alpha=0.2','\alpha=0.5','\alpha=0.8','\alpha=1');
% title('$r=0.3$','Interpreter','latex')
% xlabel('Sparsity Level s')
% ylabel('SNR')
% 
% subplot(1,2,2)
% plot(s,error2(:,1),'-o',s,error2(:,2),'-+',s,error2(:,3),'-*',s,error2(:,4),'-s',s,error2(:,5),'-d');
% set(gca,'FontSize',22);
% legend('\alpha=0','\alpha=0.2','\alpha=0.5','\alpha=0.8','\alpha=1');
% title('$r=0.7$','Interpreter','latex')
% xlabel('Sparsity Level s')
% ylabel('SNR')