function x = lp_unconstrained(A,y,p,alpha,lambda)
%
%    lp_unconstrained solves problems of the following form:
%		
%    minimize 0.5*||A*x - y||_2^2+\lambda*(||x||_p^p-alpha*||x||_1^p)
%
%   where A is the measurement matrix and y is the vector of measurements,
%   x is the reconstructed signal. 
%      

epsilon = 1;tol=1e-3; maxit=200;
% u_0 is the L_2 solution which would be exact if m = n,
% but in Compressed expactations are that m is less than n
u_0 = A\y;
u_old = u_0;
j=0;
[m N]=size(A);
while epsilon > 10^(-8) && j<=200
	j = j + 1;
	w = (u_old.^(2) + epsilon).^(p/2-1);
	Q= diag(w,0);
    uit_0=zeros(N,1);
    uit_old=uit_0;
    for it = 1:maxit
    uit_new = (A'*A+2*lambda*Q)\(A'*y+alpha*lambda*(norm(u_old,1)^(p-1))*sign(uit_old));
    relerr = sqrt(sum((uit_new-uit_old).^2))/max(sqrt(sum(uit_old.^2)),1);
    uit_old=uit_new;
    if relerr < tol
        break;
    end
    end 
    u_new=uit_new;
    
	if lt(norm(u_new - u_old,2),epsilon^(1/2)/100)
		epsilon = epsilon /10;
	end
	u_old = u_new;
end
x=u_new;