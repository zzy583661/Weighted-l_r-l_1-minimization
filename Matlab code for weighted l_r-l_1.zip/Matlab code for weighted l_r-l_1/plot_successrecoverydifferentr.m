% Codes for Figure 3 (noiseless case) and Figure 5 (noisy case)
% Successful recovery rate for different r with alpha=0.2 and alpha=0.8
s=[10 12 14 16 18 20 22 24 26 28 30 32 34 36]';
noise_type=1;
nsim=100;
p=[0.01 0.2 0.5 0.8 1]';
alpha1=0.2;
error1=zeros(length(s),length(p));
for i=1:length(p)
    for j=1:length(s)
    error1(j,i)=test_unconstrained(s(j),p(i),alpha1,noise_type,nsim);
    end
end
alpha2=0.8;
error2=zeros(length(s),length(p));
for i=1:length(p)
    for j=1:length(s)
    error2(j,i)=test_unconstrained(s(j),p(i),alpha2,noise_type,nsim);
    end
end

%% noisy_type=0 noisless case
% subplot(1,2,1)
% plot(s,error1(:,1),'-o',s,error1(:,2),'-+',s,error1(:,3),'-*',s,error1(:,4),'-s',s,error1(:,5),'-d');
% set(gca,'FontSize',22);
% legend('r=0.01','r=0.2','r=0.5','r=0.8','r=1');
% title('$\alpha=0.2$','Interpreter','latex')
% xlabel('Sparsity Level s')
% ylabel('Successful Rate')
% 
% subplot(1,2,2)
% plot(s,error2(:,1),'-o',s,error2(:,2),'-+',s,error2(:,3),'-*',s,error2(:,4),'-s',s,error2(:,5),'-d');
% set(gca,'FontSize',22);
% legend('r=0.01','r=0.2','r=0.5','r=0.8','r=1');
% title('$\alpha=0.8$','Interpreter','latex')
% xlabel('Sparsity Level s')
% ylabel('Successful Rate')

%% noisy_type=1 noisy case
subplot(1,2,1)
plot(s,error1(:,1),'-o',s,error1(:,2),'-+',s,error1(:,3),'-*',s,error1(:,4),'-s',s,error1(:,5),'-d');
set(gca,'FontSize',22);
legend('r=0.01','r=0.2','r=0.5','r=0.8','r=1');
title('$\alpha=0.2$','Interpreter','latex')
xlabel('Sparsity Level s')
ylabel('SNR')

subplot(1,2,2)
plot(s,error2(:,1),'-o',s,error2(:,2),'-+',s,error2(:,3),'-*',s,error2(:,4),'-s',s,error2(:,5),'-d');
set(gca,'FontSize',22);
legend('r=0.01','r=0.2','r=0.5','r=0.8','r=1');
title('$\alpha=0.8$','Interpreter','latex')
xlabel('Sparsity Level s')
ylabel('SNR')