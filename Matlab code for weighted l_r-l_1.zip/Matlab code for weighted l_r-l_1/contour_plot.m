%% Code for Figure 1-Contour plots for weighted l_r-l_1 norms

%% lr^r-alphal_1^r fix r=0.5 for different alpha
subplot(2,3,1)
x = linspace(-1,1);
y = linspace(-1,1);
[X,Y] = meshgrid(x,y);
Z = (abs(X).^0.5+abs(Y).^0.5);
contour(X,Y,Z)
%title('$\ell_{0.5}-\ell_1$','Interpreter','latex','Color','r')
set(gca,'FontSize',22);
title('$\alpha=0$','Interpreter','latex')

subplot(2,3,2)
x = linspace(-1,1);
y = linspace(-1,1);
[X,Y] = meshgrid(x,y);
Z = (abs(X).^0.5+abs(Y).^0.5)-0.3*(abs(X)+abs(Y)).^0.5;
contour(X,Y,Z)
%title('$\ell_{0.5}-0.3\ell_1$','Interpreter','latex','Color','r')
set(gca,'FontSize',22);
title('$\alpha=0.3$','Interpreter','latex')

subplot(2,3,3)
x = linspace(-1,1);
y = linspace(-1,1);
[X,Y] = meshgrid(x,y);
Z = (abs(X).^0.5+abs(Y).^0.5)-(abs(X)+abs(Y)).^0.5;
contour(X,Y,Z)
%title('$\ell_{0.5}-0.7\ell_1$','Interpreter','latex','Color','r')
set(gca,'FontSize',22);
title('$\alpha=1$','Interpreter','latex')

%% fix alpha=1 for different r
subplot(2,3,4)
x = linspace(-1,1);
y = linspace(-1,1);
[X,Y] = meshgrid(x,y);
Z = (abs(X).^0.1+abs(Y).^0.1)-(abs(X)+abs(Y)).^0.1;
contour(X,Y,Z)
%title('$\ell_{0.5}-\ell_1$','Interpreter','latex','Color','r')
set(gca,'FontSize',22);
title('$r=0.1$','Interpreter','latex')

subplot(2,3,5)
x = linspace(-1,1);
y = linspace(-1,1);
[X,Y] = meshgrid(x,y);
Z = (abs(X).^0.4+abs(Y).^0.4)-(abs(X)+abs(Y)).^0.4;
contour(X,Y,Z)
%title('$\ell_{0.5}-0.3\ell_1$','Interpreter','latex','Color','r')
set(gca,'FontSize',22);
title('$r=0.4$','Interpreter','latex')

subplot(2,3,6)
x = linspace(-1,1);
y = linspace(-1,1);
[X,Y] = meshgrid(x,y);
Z = (abs(X).^0.7+abs(Y).^0.7)-(abs(X)+abs(Y)).^0.7;
contour(X,Y,Z)
%title('$\ell_{0.5}-0.7\ell_1$','Interpreter','latex','Color','r')
set(gca,'FontSize',22);
title('$r=0.7$','Interpreter','latex')



