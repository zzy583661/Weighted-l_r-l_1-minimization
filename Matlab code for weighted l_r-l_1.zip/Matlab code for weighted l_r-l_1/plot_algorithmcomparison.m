%% Code for Figure 6-Sparse signal recovery performance comparison 
s=[10 12 14 16 18 20 22 24 26 28 30 32 34 36]';
noise_type=0;
nsim=100;
error=zeros(length(s),6);
for i=1:length(s)
    [error(i,1),error(i,2),error(i,3),error(i,4),error(i,5),error(i,6)]=algorithm_comparison(s(i),noise_type,nsim);
end

plot(s,error(:,1),'-o',s,error(:,2),'-+',s,error(:,3),'-*',s,error(:,4),'-s',s,error(:,5),'-d',s,error(:,6),'-^');
set(gca,'FontSize',22);
leg1=legend('$\ell_{0.5}$','$\ell_{0.5}-\ell_{1}$','ADMM-Lasso','$\ell_{1}-\ell_{2}$','CoSaMP','IHT');
set(leg1,'Interpreter','latex');
xlabel('Sparsity Level s')
ylabel('Successful Rate')
 
