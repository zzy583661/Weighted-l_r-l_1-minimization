function [err_alpha0,err_alpha1,err_lasso,err_l1l2,err_cosamp,err_aiht]= algorithm_comparison(k,noise_type,nsim)
% Main code for recovery performance comparison via different algorithms
% l_p constrained- weighted l_p-l_1 (alpha=0 (l_p), alpha=1 (l_p-l_1))
% lasso- ADMM_lasso 
% unconstrainedL1L2- l_1-l_2 minimization
% cosamp- CoSaMP algorithm
% hard_l0_Mterm -Iterative Hard Thresholding (IHT) algorithm
%tic;
randn('seed',1);
%% noise_type
if noise_type==0
sigma=0;
lambda=1e-6;

elseif noise_type==1
sigma=0.01;
lambda=1e-2;
end
%%
rase_alpha0=zeros(nsim,1);
rase_alpha1=zeros(nsim,1);
rase_lasso=zeros(nsim,1);
rase_l1l2=zeros(nsim,1);
rase_cosamp=zeros(nsim,1);
rase_aiht=zeros(nsim,1);
%%Gaussian random matrix
N=256;
m=64;
rng(0,'twister');
A = randn(m,N)/sqrt(m); 


for j=1:nsim
 
%% simulate the signal
x0 = zeros(N,1); 
x0(randsample(N,k)) = randn(k,1);

%% main recovery code
y = A*x0+sigma*randn(m,1);
p=0.5;
xhat_alpha0=lp_unconstrained(A,y,p,0,lambda);
xhat_alpha1=lp_unconstrained(A,y,p,1,lambda);
xhat_lasso=lasso(A,y,lambda,1e-5,1);

pm.lambda=lambda;
xhat_l1l2=unconstrainedL1L2(A,y,pm);

xhat_cosamp=cosamp(A,y,k,1e-8,200);

xhat_aiht=hard_l0_Mterm(y,A,N,k,'verbose',true);

if noise_type==0
    rase_alpha0(j)=norm(x0-xhat_alpha0)/norm(x0);
    if rase_alpha0(j)<1e-3
        rase_alpha0(j)=1;
    else
        rase_alpha0(j)=0;
    end
    rase_alpha1(j)=norm(x0-xhat_alpha1)/norm(x0);
    if rase_alpha1(j)<1e-3
        rase_alpha1(j)=1;
    else
        rase_alpha1(j)=0;
    end
    rase_lasso(j)=norm(x0-xhat_lasso)/norm(x0);
    if rase_lasso(j)<1e-3
        rase_lasso(j)=1;
    else
        rase_lasso(j)=0;
    end
    rase_l1l2(j)=norm(x0-xhat_l1l2)/norm(x0);
    if rase_l1l2(j)<1e-3
        rase_l1l2(j)=1;
    else
        rase_l1l2(j)=0;
    end
    rase_cosamp(j)=norm(x0-xhat_cosamp)/norm(x0);
    if rase_cosamp(j)<1e-3
        rase_cosamp(j)=1;
    else
        rase_cosamp(j)=0;
    end

     rase_aiht(j)=norm(x0-xhat_aiht)/norm(x0);
    if rase_aiht(j)<1e-3
        rase_aiht(j)=1;
    else
        rase_aiht(j)=0;
    end
    
elseif noise_type== 1
rase_alpha0(j)=20*log10(norm(x0)/norm(x0-xhat_alpha0));
rase_alpha1(j)=20*log10(norm(x0)/norm(x0-xhat_alpha1));
rase_lasso(j)=20*log10(norm(x0)/norm(x0-xhat_lasso));
rase_l1l2(j)=20*log10(norm(x0)/norm(x0-xhat_l1l2));
rase_cosamp(j)=20*log10(norm(x0)/norm(x0-xhat_cosamp));
rase_aiht(j)=20*log10(norm(x0)/norm(x0-xhat_aiht));
end


end 
%% error calculation 
err_alpha0=mean(rase_alpha0);
err_alpha1=mean(rase_alpha1);
err_lasso=mean(rase_lasso);
err_l1l2=mean(rase_l1l2);
err_cosamp=mean(rase_cosamp);
err_aiht=mean(rase_aiht);
%toc